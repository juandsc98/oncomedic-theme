import './main.css';

alert('howdy partner! :) ');