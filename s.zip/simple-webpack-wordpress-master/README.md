# simple-webpack-wordpress
A simple setup of webpack for JS and PostCSS (w/ Tailwind) compiling 

1. Clone the repository into your active theme's folder
2. Run `npm install`
3. Run `npm run start`
